<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Description</key>
	<string>MySQL @VERSION@@MYSQL_SERVER_SUFFIX@</string>
	<key>OrderPreference</key>
	<string>None</string>
	<key>Provides</key>
	<array>
		<string>MySQL</string>
	</array>
	<key>Uses</key>
	<array>
		<string>Network</string>
		<string>Resolver</string>
	</array>
	</dict>
</plist>
