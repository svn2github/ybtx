//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestPlugInRunner.rc
//
#define IDS_ERROR_SELECT_TEST           1
#define IDS_ERRORLIST_TYPE              2
#define IDS_ERRORLIST_NAME              3
#define IDS_ERRORLIST_FAILED_CONDITION  4
#define IDS_ERRORLIST_LINE_NUMBER       5
#define IDS_ERRORLIST_FILE_NAME         6
#define IDR_MAINFRAME                   128
#define IDR_ACCELERATOR_TEST_RUNNER     131
#define IDC_LIST                        1000
#define ID_RUN                          1001
#define ID_STOP                         1002
#define IDC_PROGRESS                    1003
#define IDC_INDICATOR                   1004
#define IDC_COMBO_TEST                  1005
#define IDC_STATIC_RUNS                 1007
#define IDC_STATIC_ERRORS               1008
#define IDC_STATIC_FAILURES             1009
#define IDC_EDIT_TIME                   1010
#define IDC_BUTTON1                     1011
#define IDC_BROWSE_TEST                 1011
#define IDC_TREE_TEST                   1012
#define IDC_DETAILS                     1012
#define IDC_CHECK_AUTORUN               1013
#define IDC_RUNNING_TEST_CASE_LABEL     1016
#define IDC_STATIC_TEST_NAME            1017
#define IDC_STATIC_PROGRESS             1018
#define IDC_STATIC_LABEL_RUNS           1019
#define IDC_STATIC_LABEL_ERRORS         1020
#define IDC_STATIC_LABEL_FAILURES       1021
#define IDC_STATIC_PROGRESS_BAR         1022
#define IDC_STATIC_DETAILS              1023
#define IDC_CHOOSE_DLL                  1040
#define IDC_RELOAD_DLL                  1041
#define ID_QUIT_APPLICATION             32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
