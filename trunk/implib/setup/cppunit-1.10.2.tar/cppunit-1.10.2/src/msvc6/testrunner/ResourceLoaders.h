#if !defined(AFX_RESOURCELOADERS_H)
#define AFX_RESOURCELOADERS_H

/// loads a CString from the test runner DLL module 
CString loadCString(UINT stringId);

#endif // !defined(AFX_RESOURCELOADERS_H)
